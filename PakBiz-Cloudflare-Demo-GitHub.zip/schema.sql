CREATE TABLE IF NOT EXISTS demo_state (
  id TEXT PRIMARY KEY,
  payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS demo_backups (
  filename TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS demo_uploads (
  name TEXT PRIMARY KEY,
  content_type TEXT NOT NULL,
  data TEXT NOT NULL
);
