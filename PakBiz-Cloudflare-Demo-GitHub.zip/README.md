# PakBiz Cloudflare demo

This is a public, browser-based demonstration build. It does not contain the supplied RAR's `data/database.json`, license files, or the Render package. The demo server uses fictional branding, a demo-only license response, and an isolated D1 database.

## Deploy with Cloudflare Pages

1. Create a GitHub repository and upload the contents of this folder.
2. In Cloudflare, create a Pages project and connect that repository.
3. Set the build command to `exit 0` and the output directory to `dist`.
4. Create a D1 database named `pakbiz-demo`.
5. In the D1 console, run the SQL in `schema.sql` once.
6. In the Pages project's Settings → Functions → D1 database bindings, bind the database to the variable `DB`, then redeploy.
7. Share the `*.pages.dev` URL with customers.

## Demo sign-in

- Username: `demo`
- Password: `PakBizDemo123!`

The demo uses one shared database for all visitors. It starts with a clean sample store; customer edits are visible to other visitors. Do not enter real business/customer information. Free D1 limits apply, and uploaded demo logos and backups are stored in D1.
