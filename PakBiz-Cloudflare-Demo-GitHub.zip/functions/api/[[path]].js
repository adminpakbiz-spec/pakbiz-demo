const DEMO_LICENSE = {
  hardwareId: "PAKBIZ-DEMO",
  isActivated: true,
  licenseKey: "",
  licenseType: "DEMO",
  clientName: "PakBiz Web Demo",
  activationDate: new Date().toISOString(),
  expiryDate: "",
  statusText: "Demo Mode",
};

function freshDemoData() {
  const today = new Date().toISOString();
  return {
    version: "3.0.0",
    lastUpdated: today,
    businessProfile: {
      id: "demo-profile",
      shopName: "PakBiz Demo Store",
      tagline: "Practice environment — sample data only",
      phone: "",
      phone2: "",
      whatsapp: "",
      email: "",
      address: "Demo environment",
      city: "Online",
      ntn: "",
      strn: "",
      bankName: "",
      bankAccountTitle: "",
      bankIban: "",
      bankBranch: "",
      logoUrl: "",
      currency: "PKR",
      invoiceFooterTerms: "Demo account: do not enter real business or customer information.",
      returnPolicy: "Demo policy",
      warrantyPolicy: "Demo policy",
      invoicePrefixes: {
        retail: "DEMO-INV-",
        taxInvoice: "DEMO-TAX-",
        quotation: "DEMO-QUO-",
        proforma: "DEMO-PRO-",
        purchase: "DEMO-PUR-",
        deliveryChallan: "DEMO-CHL-",
        customerReceipt: "DEMO-REC-",
        repairJob: "DEMO-REP-",
      },
    },
    profiles: [],
    users: [{ id: "usr-demo", username: "demo", fullName: "PakBiz Demo User", role: "Owner", password: "PakBizDemo123!", pin: "123456", securityQuestion: "", securityAnswer: "", active: true }],
    laptopLots: [], laptopUnits: [], mobileUnits: [], mobileLots: [],
    refurbishmentLogs: [], componentMovements: [], repairJobs: [], invoices: [],
    customers: [], suppliers: [], ledgerTransactions: [], productInventory: [],
    expenses: [], auditLogs: [], recycleBin: [],
    license: DEMO_LICENSE,
  };
}

async function jsonBody(request, maxBytes = 1800000) {
  const text = await request.text();
  if (text.length > maxBytes) throw new Error("Request is too large for the public demo.");
  return JSON.parse(text || "{}");
}

export async function onRequest({ request, env }) {
  const url = new URL(request.url);
  const path = url.pathname;
  const db = env.DB;

  if (path === "/api/license/status" || path === "/api/license/activate") return Response.json(DEMO_LICENSE);
  if (path === "/api/hardware-id") return Response.json({ hardwareId: DEMO_LICENSE.hardwareId });

  if (path === "/api/data" && request.method === "GET") {
    let row = await db.prepare("SELECT payload FROM demo_state WHERE id = 'main'").first();
    if (!row) {
      const seed = freshDemoData();
      await db.prepare("INSERT OR IGNORE INTO demo_state (id, payload) VALUES ('main', ?)").bind(JSON.stringify(seed)).run();
      row = await db.prepare("SELECT payload FROM demo_state WHERE id = 'main'").first();
    }
    const data = JSON.parse(row.payload);
    data.license = DEMO_LICENSE;
    return Response.json(data);
  }

  if (path === "/api/data" && request.method === "POST") {
    try {
      const data = await jsonBody(request);
      if (!data?.version || !Array.isArray(data.invoices)) return Response.json({ error: "Invalid demo data." }, { status: 400 });
      data.license = DEMO_LICENSE;
      const saved = await db.prepare("INSERT INTO demo_state (id, payload) VALUES ('main', ?) ON CONFLICT(id) DO UPDATE SET payload = excluded.payload").bind(JSON.stringify(data)).run();
      return Response.json({ success: true, changes: saved.meta?.changes ?? 1 });
    } catch (error) {
      return Response.json({ error: error.message || "Could not save demo data." }, { status: 400 });
    }
  }

  if (path === "/api/backups" && request.method === "GET") {
    const result = await db.prepare("SELECT filename, length(payload) AS sizeBytes, created_at AS createdAt FROM demo_backups ORDER BY created_at DESC").all();
    return Response.json({ backups: result.results || [], backupDir: "Demo backups" });
  }

  if (path === "/api/backup/create" && request.method === "POST") {
    try {
      const body = await jsonBody(request);
      if (!body.data?.version || !Array.isArray(body.data.invoices)) return Response.json({ error: "Database snapshot is invalid." }, { status: 400 });
      const filename = `PakBiz-demo-${new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19)}.json`;
      await db.prepare("INSERT INTO demo_backups (filename, payload, created_at) VALUES (?, ?, ?)").bind(filename, JSON.stringify(body.data), new Date().toISOString()).run();
      return Response.json({ success: true, filename, path: "Demo backups", driveUploaded: false });
    } catch (error) {
      return Response.json({ error: error.message || "Could not create demo backup." }, { status: 400 });
    }
  }

  if (path === "/api/backup/restore" && request.method === "POST") {
    try {
      const body = await jsonBody(request);
      const row = await db.prepare("SELECT payload FROM demo_backups WHERE filename = ?").bind(String(body.filename || "")).first();
      if (!row) return Response.json({ error: "Demo backup not found." }, { status: 404 });
      const data = JSON.parse(row.payload);
      data.license = DEMO_LICENSE;
      await db.prepare("INSERT INTO demo_state (id, payload) VALUES ('main', ?) ON CONFLICT(id) DO UPDATE SET payload = excluded.payload").bind(JSON.stringify(data)).run();
      return Response.json({ success: true, message: "Demo data restored." });
    } catch (error) {
      return Response.json({ error: error.message || "Could not restore demo backup." }, { status: 400 });
    }
  }

  if (path === "/api/upload-logo" && request.method === "POST") {
    try {
      const body = await jsonBody(request, 1400000);
      const match = String(body.base64Data || "").match(/^data:(image\/(?:png|jpeg));base64,([A-Za-z0-9+/=]+)$/);
      if (!match) return Response.json({ error: "A PNG or JPEG image is required." }, { status: 400 });
      const name = `demo_${crypto.randomUUID()}.${match[1].includes("png") ? "png" : "jpg"}`;
      await db.prepare("INSERT INTO demo_uploads (name, content_type, data) VALUES (?, ?, ?)").bind(name, match[1], match[2]).run();
      return Response.json({ success: true, url: `/data/uploads/${name}` });
    } catch (error) {
      return Response.json({ error: error.message || "Could not upload demo logo." }, { status: 400 });
    }
  }

  return Response.json({ error: "Demo API route not found." }, { status: 404 });
}
