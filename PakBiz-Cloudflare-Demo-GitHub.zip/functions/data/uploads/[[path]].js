export async function onRequest({ request, env, params }) {
  if (request.method !== "GET") return new Response("Not found", { status: 404 });
  const path = new URL(request.url).pathname;
  const name = path.split("/").pop();
  if (!name || name.includes("..")) return new Response("Not found", { status: 404 });
  const row = await env.DB.prepare("SELECT content_type, data FROM demo_uploads WHERE name = ?").bind(name).first();
  if (!row) return new Response("Not found", { status: 404 });
  const binary = Uint8Array.from(atob(row.data), (c) => c.charCodeAt(0));
  return new Response(binary, { headers: { "Content-Type": row.content_type, "Cache-Control": "public, max-age=3600" } });
}
